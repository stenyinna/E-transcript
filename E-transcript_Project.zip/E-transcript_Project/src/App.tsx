import React, { useState } from 'react';
import LandingPage from './components/LandingPage';
import StudentDashboard from './components/StudentDashboard';
import AdminDashboard from './components/AdminDashboard';
import VerificationPortal from './components/VerificationPortal';
import AuthModal from './components/AuthModal';

export type UserRole = 'student' | 'admin' | 'company';
export type RequestStatus = 'pending' | 'processing' | 'completed' | 'sent';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  matricNumber?: string;
  graduationYear?: number;
  degree?: string;
  department?: string;
}

export interface TranscriptRequest {
  id: string;
  userId: string;
  status: RequestStatus;
  requestDate: string;
  completionDate?: string;
  recipientEmail: string;
  recipientAddress: string;
  amount: number;
}

export interface VerificationRequest {
  id: string;
  companyEmail: string;
  companyPhone: string;
  employeeMatricNumber: string;
  status: RequestStatus;
  requestDate: string;
  amount: number;
}

function App() {
  const [currentView, setCurrentView] = useState<'landing' | 'student' | 'admin' | 'verification'>('landing');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Mock data
  const [transcriptRequests, setTranscriptRequests] = useState<TranscriptRequest[]>([
    {
      id: '1',
      userId: '1',
      status: 'processing',
      requestDate: '2024-01-15',
      recipientEmail: 'hr@company.com',
      recipientAddress: '123 Business St, City',
      amount: 50
    },
    {
      id: '2',
      userId: '2',
      status: 'completed',
      requestDate: '2024-01-10',
      completionDate: '2024-01-20',
      recipientEmail: 'admissions@university.edu',
      recipientAddress: '456 Academic Ave, University City',
      amount: 50
    }
  ]);

  const [verificationRequests, setVerificationRequests] = useState<VerificationRequest[]>([
    {
      id: '1',
      companyEmail: 'hr@techcorp.com',
      companyPhone: '+1234567890',
      employeeMatricNumber: 'CS/2020/001',
      status: 'pending',
      requestDate: '2024-01-18',
      amount: 25
    }
  ]);

  const handleLogin = (email: string, password: string) => {
    // Mock authentication
    const mockUser: User = {
      id: '1',
      name: 'John Doe',
      email: email,
      role: email.includes('admin') ? 'admin' : 'student',
      matricNumber: 'CS/2020/001',
      graduationYear: 2024,
      degree: 'Bachelor of Science in Computer Science',
      department: 'Computer Science'
    };
    
    setCurrentUser(mockUser);
    setShowAuthModal(false);
    setCurrentView(mockUser.role === 'admin' ? 'admin' : 'student');
  };

  const handleRegister = (name: string, email: string, password: string, matricNumber: string) => {
    // Mock registration
    const newUser: User = {
      id: Date.now().toString(),
      name,
      email,
      role: 'student',
      matricNumber,
      graduationYear: 2024,
      degree: 'Bachelor of Science',
      department: 'Computer Science'
    };
    
    setCurrentUser(newUser);
    setShowAuthModal(false);
    setCurrentView('student');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('landing');
  };

  const openAuth = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setShowAuthModal(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {currentView === 'landing' && (
        <LandingPage
          onLogin={() => openAuth('login')}
          onRegister={() => openAuth('register')}
          onVerification={() => setCurrentView('verification')}
        />
      )}
      
      {currentView === 'student' && currentUser && (
        <StudentDashboard
          user={currentUser}
          transcriptRequests={transcriptRequests.filter(req => req.userId === currentUser.id)}
          onLogout={handleLogout}
          onBackToHome={() => setCurrentView('landing')}
        />
      )}
      
      {currentView === 'admin' && currentUser && (
        <AdminDashboard
          user={currentUser}
          transcriptRequests={transcriptRequests}
          verificationRequests={verificationRequests}
          onLogout={handleLogout}
          onBackToHome={() => setCurrentView('landing')}
          onUpdateTranscriptStatus={(id, status) => {
            setTranscriptRequests(prev => 
              prev.map(req => req.id === id ? { ...req, status } : req)
            );
          }}
          onUpdateVerificationStatus={(id, status) => {
            setVerificationRequests(prev => 
              prev.map(req => req.id === id ? { ...req, status } : req)
            );
          }}
        />
      )}
      
      {currentView === 'verification' && (
        <VerificationPortal
          onBackToHome={() => setCurrentView('landing')}
          onSubmitVerification={(request) => {
            const newRequest: VerificationRequest = {
              ...request,
              id: Date.now().toString(),
              status: 'pending',
              requestDate: new Date().toISOString().split('T')[0],
              amount: 25
            };
            setVerificationRequests(prev => [...prev, newRequest]);
          }}
        />
      )}

      {showAuthModal && (
        <AuthModal
          mode={authMode}
          onClose={() => setShowAuthModal(false)}
          onLogin={handleLogin}
          onRegister={handleRegister}
          onSwitchMode={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
        />
      )}
    </div>
  );
}

export default App;