import React, { useState } from 'react';
import { User, TranscriptRequest, VerificationRequest, RequestStatus } from '../App';
import {
  Home,
  LogOut,
  BarChart3,
  FileText,
  Users,
  Mail,
  HelpCircle,
  Shield,
  Activity,
  DollarSign,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertCircle,
  Search,
  Filter,
  Download,
  Eye,
  Edit,
  Plus,
  X,
  Trash2,
  Save
} from 'lucide-react';

interface AdminDashboardProps {
  user: User;
  transcriptRequests: TranscriptRequest[];
  verificationRequests: VerificationRequest[];
  onLogout: () => void;
  onBackToHome: () => void;
  onUpdateTranscriptStatus: (id: string, status: RequestStatus) => void;
  onUpdateVerificationStatus: (id: string, status: RequestStatus) => void;
}

interface UserData {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin' | 'company';
  matricNumber?: string;
  graduationYear?: number;
  degree?: string;
  department?: string;
  status: 'active' | 'inactive' | 'suspended';
  createdAt: string;
}

export default function AdminDashboard({
  user,
  transcriptRequests,
  verificationRequests,
  onLogout,
  onBackToHome,
  onUpdateTranscriptStatus,
  onUpdateVerificationStatus
}: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'requests' | 'users' | 'messaging' | 'support' | 'roles' | 'logs'>('overview');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'transcripts' | 'verifications'>('all');
  
  // User Management State
  const [users, setUsers] = useState<UserData[]>([
    {
      id: '1',
      name: 'John Doe',
      email: 'john@example.com',
      role: 'student',
      matricNumber: 'CS/2020/001',
      graduationYear: 2024,
      degree: 'Computer Science',
      department: 'Engineering',
      status: 'active',
      createdAt: '2024-01-15'
    },
    {
      id: '2',
      name: 'Jane Smith',
      email: 'jane@example.com',
      role: 'student',
      matricNumber: 'EE/2021/045',
      graduationYear: 2025,
      degree: 'Electrical Engineering',
      department: 'Engineering',
      status: 'active',
      createdAt: '2024-02-20'
    },
    {
      id: '3',
      name: 'Admin User',
      email: 'admin@system.com',
      role: 'admin',
      status: 'active',
      createdAt: '2024-01-01'
    }
  ]);
  
  const [showUserModal, setShowUserModal] = useState(false);
  const [modalMode, setModalMode] = useState<'add' | 'edit' | 'view'>('add');
  const [selectedUser, setSelectedUser] = useState<UserData | null>(null);
  const [userSearchTerm, setUserSearchTerm] = useState('');
  const [userFormData, setUserFormData] = useState<Partial<UserData>>({
    name: '',
    email: '',
    role: 'student',
    matricNumber: '',
    graduationYear: new Date().getFullYear(),
    degree: '',
    department: '',
    status: 'active'
  });

  // Calculate financial metrics
  const totalRevenue = [
    ...transcriptRequests.map(r => r.amount),
    ...verificationRequests.map(r => r.amount)
  ].reduce((sum, amount) => sum + amount, 0);

  const transcriptRevenue = transcriptRequests.reduce((sum, r) => sum + r.amount, 0);
  const verificationRevenue = verificationRequests.reduce((sum, r) => sum + r.amount, 0);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'processing':
        return <AlertCircle className="h-4 w-4 text-blue-500" />;
      case 'completed':
      case 'sent':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
      case 'sent':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getUserStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-gray-100 text-gray-800';
      case 'suspended':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-purple-100 text-purple-800';
      case 'student':
        return 'bg-blue-100 text-blue-800';
      case 'company':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // User Management Functions
  const handleAddNewUser = () => {
    setModalMode('add');
    setUserFormData({
      name: '',
      email: '',
      role: 'student',
      matricNumber: '',
      graduationYear: new Date().getFullYear(),
      degree: '',
      department: '',
      status: 'active'
    });
    setSelectedUser(null);
    setShowUserModal(true);
  };

  const handleViewUser = (userId: string) => {
    const user = users.find(u => u.id === userId);
    if (user) {
      setSelectedUser(user);
      setUserFormData(user);
      setModalMode('view');
      setShowUserModal(true);
    }
  };

  const handleEditUser = (userId: string) => {
    const user = users.find(u => u.id === userId);
    if (user) {
      setSelectedUser(user);
      setUserFormData(user);
      setModalMode('edit');
      setShowUserModal(true);
    }
  };

  const handleDeleteUser = (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      setUsers(prev => prev.filter(u => u.id !== userId));
    }
  };

  const handleSaveUser = () => {
    if (modalMode === 'add') {
      const newUser: UserData = {
        ...userFormData as UserData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString().split('T')[0]
      };
      setUsers(prev => [...prev, newUser]);
    } else if (modalMode === 'edit' && selectedUser) {
      setUsers(prev => prev.map(u => 
        u.id === selectedUser.id ? { ...userFormData as UserData, id: selectedUser.id } : u
      ));
    }
    setShowUserModal(false);
  };

  const handleUserFormChange = (field: keyof UserData, value: any) => {
    setUserFormData(prev => ({ ...prev, [field]: value }));
  };

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
    user.matricNumber?.toLowerCase().includes(userSearchTerm.toLowerCase())
  );

  const StatusUpdateButton = ({ currentStatus, onUpdate }: { currentStatus: RequestStatus, onUpdate: (status: RequestStatus) => void }) => {
    const nextStatus: Record<RequestStatus, RequestStatus> = {
      pending: 'processing',
      processing: 'completed',
      completed: 'sent',
      sent: 'sent'
    };

    const nextStatusLabel: Record<RequestStatus, string> = {
      pending: 'Start Processing',
      processing: 'Mark Complete',
      completed: 'Mark as Sent',
      sent: 'Completed'
    };

    if (currentStatus === 'sent') {
      return (
        <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
          Completed
        </span>
      );
    }

    return (
      <button
        onClick={() => onUpdate(nextStatus[currentStatus])}
        className="px-3 py-1 bg-blue-600 text-white rounded-full text-sm font-medium hover:bg-blue-700 transition-colors"
      >
        {nextStatusLabel[currentStatus]}
      </button>
    );
  };

  const UserModal = () => (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-2xl font-bold text-gray-900">
              {modalMode === 'add' ? 'Add New User' : 
               modalMode === 'edit' ? 'Edit User' : 'User Details'}
            </h3>
            <button
              onClick={() => setShowUserModal(false)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="h-5 w-5 text-gray-500" />
            </button>
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={userFormData.name || ''}
                  onChange={(e) => handleUserFormChange('name', e.target.value)}
                  disabled={modalMode === 'view'}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                  placeholder="Enter full name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={userFormData.email || ''}
                  onChange={(e) => handleUserFormChange('email', e.target.value)}
                  disabled={modalMode === 'view'}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                  placeholder="Enter email address"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Role *
                </label>
                <select
                  value={userFormData.role || 'student'}
                  onChange={(e) => handleUserFormChange('role', e.target.value)}
                  disabled={modalMode === 'view'}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                >
                  <option value="student">Student</option>
                  <option value="admin">Admin</option>
                  <option value="company">Company</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Status *
                </label>
                <select
                  value={userFormData.status || 'active'}
                  onChange={(e) => handleUserFormChange('status', e.target.value)}
                  disabled={modalMode === 'view'}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="suspended">Suspended</option>
                </select>
              </div>
            </div>

            {userFormData.role === 'student' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Matriculation Number
                  </label>
                  <input
                    type="text"
                    value={userFormData.matricNumber || ''}
                    onChange={(e) => handleUserFormChange('matricNumber', e.target.value)}
                    disabled={modalMode === 'view'}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                    placeholder="e.g., CS/2020/001"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Graduation Year
                  </label>
                  <input
                    type="number"
                    value={userFormData.graduationYear || ''}
                    onChange={(e) => handleUserFormChange('graduationYear', parseInt(e.target.value))}
                    disabled={modalMode === 'view'}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                    placeholder="2024"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Degree Program
                  </label>
                  <input
                    type="text"
                    value={userFormData.degree || ''}
                    onChange={(e) => handleUserFormChange('degree', e.target.value)}
                    disabled={modalMode === 'view'}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                    placeholder="e.g., Computer Science"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Department
                  </label>
                  <input
                    type="text"
                    value={userFormData.department || ''}
                    onChange={(e) => handleUserFormChange('department', e.target.value)}
                    disabled={modalMode === 'view'}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                    placeholder="e.g., Engineering"
                  />
                </div>
              </div>
            )}

            {modalMode !== 'view' && (
              <div className="flex space-x-4 pt-4">
                <button
                  onClick={() => setShowUserModal(false)}
                  className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveUser}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all flex items-center justify-center space-x-2"
                >
                  <Save className="h-4 w-4" />
                  <span>{modalMode === 'add' ? 'Create User' : 'Save Changes'}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBackToHome}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <Home className="h-5 w-5" />
                <span>Home</span>
              </button>
              <div className="h-6 w-px bg-gray-300"></div>
              <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="font-medium text-gray-900">{user.name}</p>
                <p className="text-sm text-gray-600">Administrator</p>
              </div>
              <button
                onClick={onLogout}
                className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64">
            <nav className="bg-white rounded-xl shadow-sm p-4">
              <ul className="space-y-2">
                {[
                  { id: 'overview', label: 'Overview', icon: BarChart3 },
                  { id: 'requests', label: 'Requests', icon: FileText },
                  { id: 'users', label: 'Users', icon: Users },
                  { id: 'messaging', label: 'Messaging', icon: Mail },
                  { id: 'support', label: 'Support', icon: HelpCircle },
                  { id: 'roles', label: 'Roles & Access', icon: Shield },
                  { id: 'logs', label: 'Activity Logs', icon: Activity }
                ].map((item) => (
                  <li key={item.id}>
                    <button
                      onClick={() => setActiveTab(item.id as any)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                        activeTab === item.id
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <item.icon className="h-5 w-5" />
                      <span className="font-medium">{item.label}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Welcome Card */}
                <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl p-6">
                  <h2 className="text-2xl font-bold mb-2">Admin Dashboard</h2>
                  <p className="opacity-90">
                    Monitor and manage all transcript and verification requests
                  </p>
                </div>

                {/* Financial Overview */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-white rounded-xl p-6 shadow-sm">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Total Revenue</p>
                        <p className="text-3xl font-bold text-gray-900">${totalRevenue}</p>
                      </div>
                      <DollarSign className="h-8 w-8 text-green-600" />
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-xl p-6 shadow-sm">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Transcript Revenue</p>
                        <p className="text-3xl font-bold text-blue-600">${transcriptRevenue}</p>
                      </div>
                      <FileText className="h-8 w-8 text-blue-600" />
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-xl p-6 shadow-sm">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Verification Revenue</p>
                        <p className="text-3xl font-bold text-purple-600">${verificationRevenue}</p>
                      </div>
                      <Shield className="h-8 w-8 text-purple-600" />
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-xl p-6 shadow-sm">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Total Requests</p>
                        <p className="text-3xl font-bold text-indigo-600">
                          {transcriptRequests.length + verificationRequests.length}
                        </p>
                      </div>
                      <TrendingUp className="h-8 w-8 text-indigo-600" />
                    </div>
                  </div>
                </div>

                {/* Request Status Overview */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white rounded-xl shadow-sm">
                    <div className="p-6 border-b border-gray-200">
                      <h3 className="text-lg font-semibold text-gray-900">Transcript Requests</h3>
                    </div>
                    <div className="p-6">
                      <div className="space-y-4">
                        {['pending', 'processing', 'completed', 'sent'].map((status) => {
                          const count = transcriptRequests.filter(r => r.status === status).length;
                          return (
                            <div key={status} className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                {getStatusIcon(status)}
                                <span className="capitalize font-medium">{status}</span>
                              </div>
                              <span className="text-2xl font-bold text-gray-900">{count}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm">
                    <div className="p-6 border-b border-gray-200">
                      <h3 className="text-lg font-semibold text-gray-900">Verification Requests</h3>
                    </div>
                    <div className="p-6">
                      <div className="space-y-4">
                        {['pending', 'processing', 'completed', 'sent'].map((status) => {
                          const count = verificationRequests.filter(r => r.status === status).length;
                          return (
                            <div key={status} className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                {getStatusIcon(status)}
                                <span className="capitalize font-medium">{status}</span>
                              </div>
                              <span className="text-2xl font-bold text-gray-900">{count}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'requests' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">Request Management</h2>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <Filter className="h-5 w-5 text-gray-400" />
                      <select
                        value={selectedFilter}
                        onChange={(e) => setSelectedFilter(e.target.value as any)}
                        className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="all">All Requests</option>
                        <option value="transcripts">Transcripts Only</option>
                        <option value="verifications">Verifications Only</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm">
                  <div className="p-6 border-b border-gray-200">
                    <div className="flex items-center space-x-4">
                      <Search className="h-5 w-5 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search requests..."
                        className="flex-1 border-0 focus:ring-0 text-gray-900 placeholder-gray-500"
                      />
                    </div>
                  </div>

                  <div className="divide-y divide-gray-200">
                    {/* Transcript Requests */}
                    {(selectedFilter === 'all' || selectedFilter === 'transcripts') &&
                      transcriptRequests.map((request) => (
                        <div key={`transcript-${request.id}`} className="p-6">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-3 mb-2">
                                <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                                  TRANSCRIPT
                                </span>
                                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(request.status)}`}>
                                  {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                                </span>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                                <div>
                                  <p><strong>Recipient:</strong> {request.recipientEmail}</p>
                                  <p><strong>Date:</strong> {request.requestDate}</p>
                                </div>
                                <div>
                                  <p><strong>Address:</strong> {request.recipientAddress}</p>
                                  <p><strong>Amount:</strong> ${request.amount}</p>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <StatusUpdateButton
                                    currentStatus={request.status}
                                    onUpdate={(status) => onUpdateTranscriptStatus(request.id, status)}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}

                    {/* Verification Requests */}
                    {(selectedFilter === 'all' || selectedFilter === 'verifications') &&
                      verificationRequests.map((request) => (
                        <div key={`verification-${request.id}`} className="p-6">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-3 mb-2">
                                <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded text-xs font-medium">
                                  VERIFICATION
                                </span>
                                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(request.status)}`}>
                                  {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                                </span>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                                <div>
                                  <p><strong>Company:</strong> {request.companyEmail}</p>
                                  <p><strong>Phone:</strong> {request.companyPhone}</p>
                                </div>
                                <div>
                                  <p><strong>Employee ID:</strong> {request.employeeMatricNumber}</p>
                                  <p><strong>Date:</strong> {request.requestDate}</p>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <StatusUpdateButton
                                    currentStatus={request.status}
                                    onUpdate={(status) => onUpdateVerificationStatus(request.id, status)}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'users' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">User Management</h2>
                  <button
                    onClick={handleAddNewUser}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg"
                  >
                    <Plus className="h-5 w-5" />
                    <span>Add New User</span>
                  </button>
                </div>

                <div className="bg-white rounded-xl shadow-sm">
                  <div className="p-6 border-b border-gray-200">
                    <div className="flex items-center space-x-4">
                      <Search className="h-5 w-5 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search users..."
                        value={userSearchTerm}
                        onChange={(e) => setUserSearchTerm(e.target.value)}
                        className="flex-1 border-0 focus:ring-0 text-gray-900 placeholder-gray-500"
                      />
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            User
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Role
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Created
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {filteredUsers.map((userData) => (
                          <tr key={userData.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div>
                                <div className="text-sm font-medium text-gray-900">{userData.name}</div>
                                <div className="text-sm text-gray-500">{userData.email}</div>
                                {userData.matricNumber && (
                                  <div className="text-xs text-gray-400">{userData.matricNumber}</div>
                                )}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getRoleColor(userData.role)}`}>
                                {userData.role.charAt(0).toUpperCase() + userData.role.slice(1)}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getUserStatusColor(userData.status)}`}>
                                {userData.status.charAt(0).toUpperCase() + userData.status.slice(1)}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {userData.createdAt}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              <div className="flex space-x-2">
                                <button
                                  onClick={() => handleViewUser(userData.id)}
                                  className="text-blue-600 hover:text-blue-900 p-1 rounded hover:bg-blue-50 transition-colors"
                                  title="View User"
                                >
                                  <Eye className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => handleEditUser(userData.id)}
                                  className="text-gray-600 hover:text-gray-900 p-1 rounded hover:bg-gray-50 transition-colors"
                                  title="Edit User"
                                >
                                  <Edit className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => handleDeleteUser(userData.id)}
                                  className="text-red-600 hover:text-red-900 p-1 rounded hover:bg-red-50 transition-colors"
                                  title="Delete User"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {filteredUsers.length === 0 && (
                    <div className="text-center py-8">
                      <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No users found matching your search</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'messaging' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Email Messaging</h2>
                
                <div className="bg-white rounded-xl shadow-sm p-6">
                  <div className="max-w-2xl">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Send Message</h3>
                    <form className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Recipients
                        </label>
                        <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                          <option>All Users</option>
                          <option>Students Only</option>
                          <option>Companies Only</option>
                          <option>Custom List</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Subject
                        </label>
                        <input
                          type="text"
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          placeholder="Enter email subject"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Message
                        </label>
                        <textarea
                          rows={6}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          placeholder="Enter your message"
                        />
                      </div>
                      
                      <button
                        type="submit"
                        className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        Send Message
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'support' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Support Center</h2>
                
                <div className="bg-white rounded-xl shadow-sm">
                  <div className="p-6 border-b border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900">Support Tickets</h3>
                  </div>
                  <div className="p-6">
                    <div className="text-center py-8">
                      <HelpCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No support tickets</h3>
                      <p className="text-gray-600">All support requests will appear here</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'roles' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Roles & Permissions</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white rounded-xl shadow-sm p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Admin Roles</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">Super Admin</p>
                          <p className="text-sm text-gray-600">Full system access</p>
                        </div>
                        <span className="px-2 py-1 bg-red-100 text-red-800 rounded text-xs font-medium">
                          1 User
                        </span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">Staff Admin</p>
                          <p className="text-sm text-gray-600">Limited access</p>
                        </div>
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                          3 Users
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Permissions</h3>
                    <div className="space-y-2">
                      {[
                        'Manage Requests',
                        'User Management',
                        'Financial Reports',
                        'System Settings',
                        'Email Messaging',
                        'Support Management'
                      ].map((permission) => (
                        <div key={permission} className="flex items-center justify-between">
                          <span className="text-sm text-gray-700">{permission}</span>
                          <input type="checkbox" defaultChecked className="rounded" />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'logs' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Activity Logs</h2>
                
                <div className="bg-white rounded-xl shadow-sm">
                  <div className="p-6 border-b border-gray-200">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
                      <button className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-900 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                        <Download className="h-4 w-4" />
                        <span>Export</span>
                      </button>
                    </div>
                  </div>
                  <div className="divide-y divide-gray-200">
                    {[
                      { action: 'User Login', user: 'john@example.com', time: '2 minutes ago', type: 'info' },
                      { action: 'Transcript Request Updated', user: 'admin@system.com', time: '15 minutes ago', type: 'success' },
                      { action: 'New User Registration', user: 'jane@example.com', time: '1 hour ago', type: 'info' },
                      { action: 'Payment Processed', user: 'system', time: '2 hours ago', type: 'success' }
                    ].map((log, index) => (
                      <div key={index} className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className={`w-2 h-2 rounded-full ${
                              log.type === 'success' ? 'bg-green-500' : 'bg-blue-500'
                            }`}></div>
                            <div>
                              <p className="font-medium text-gray-900">{log.action}</p>
                              <p className="text-sm text-gray-600">{log.user}</p>
                            </div>
                          </div>
                          <span className="text-sm text-gray-500">{log.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {showUserModal && <UserModal />}
    </div>
  );
}