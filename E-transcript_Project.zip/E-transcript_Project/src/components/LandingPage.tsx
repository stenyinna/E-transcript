import React from 'react';
import { GraduationCap, FileText, Shield, Users, TrendingUp, Clock, CheckCircle, Star } from 'lucide-react';

interface LandingPageProps {
  onLogin: () => void;
  onRegister: () => void;
  onVerification: () => void;
}

export default function LandingPage({ onLogin, onRegister, onVerification }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-xl">
                <GraduationCap className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  EduTranscript Portal
                </h1>
                <p className="text-sm text-gray-600">Academic Excellence Verified</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={onLogin}
                className="px-6 py-2 text-blue-600 hover:text-blue-700 font-medium transition-colors duration-200"
              >
                Login
              </button>
              <button
                onClick={onRegister}
                className="px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
              >
                Get Started
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10"></div>
        <div className="relative max-w-6xl mx-auto text-center">
          <div className="mb-8">
            <span className="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-medium mb-6">
              <Star className="h-4 w-4 mr-2" />
              Trusted by 10,000+ Students & 500+ Organizations
            </span>
          </div>
          <h2 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
            Your Academic
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent block">
              Journey Verified
            </span>
          </h2>
          <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
            Seamlessly request official transcripts, access academic results, and verify credentials 
            with our secure, fast, and reliable digital platform.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16">
            <button
              onClick={onRegister}
              className="group px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl font-semibold text-lg shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 flex items-center space-x-2"
            >
              <FileText className="h-5 w-5" />
              <span>Request Transcript</span>
            </button>
            <button
              onClick={onLogin}
              className="group px-8 py-4 bg-gradient-to-r from-indigo-500 to-blue-600 text-white rounded-xl font-semibold text-lg shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 flex items-center space-x-2"
            >
              <GraduationCap className="h-5 w-5" />
              <span>View My Results</span>
            </button>
            <button
              onClick={onVerification}
              className="group px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-xl font-semibold text-lg shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 flex items-center space-x-2"
            >
              <Shield className="h-5 w-5" />
              <span>Verify Credentials</span>
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">50K+</div>
              <div className="text-gray-600">Transcripts Processed</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-green-600 mb-2">99.9%</div>
              <div className="text-gray-600">Uptime Guarantee</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-purple-600 mb-2">24/7</div>
              <div className="text-gray-600">Support Available</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-4">
              Everything You Need in One Platform
            </h3>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From transcript requests to result verification, we've streamlined every aspect 
              of academic credential management.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="group bg-gradient-to-br from-blue-50 to-indigo-50 p-8 rounded-2xl hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-blue-100">
              <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-3 rounded-xl w-fit mb-6">
                <FileText className="h-8 w-8 text-white" />
              </div>
              <h4 className="text-2xl font-bold text-gray-900 mb-4">Smart Transcript Requests</h4>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Request official transcripts with real-time tracking. Monitor status from 
                submission to delivery with automated notifications.
              </p>
              <div className="flex items-center space-x-2 text-blue-600 font-medium">
                <CheckCircle className="h-4 w-4" />
                <span>Real-time tracking</span>
              </div>
            </div>

            <div className="group bg-gradient-to-br from-green-50 to-emerald-50 p-8 rounded-2xl hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-green-100">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-3 rounded-xl w-fit mb-6">
                <GraduationCap className="h-8 w-8 text-white" />
              </div>
              <h4 className="text-2xl font-bold text-gray-900 mb-4">Secure Result Access</h4>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Download official academic results as verified PDFs with blockchain-backed 
                security and comprehensive audit trails.
              </p>
              <div className="flex items-center space-x-2 text-green-600 font-medium">
                <CheckCircle className="h-4 w-4" />
                <span>Blockchain secured</span>
              </div>
            </div>

            <div className="group bg-gradient-to-br from-purple-50 to-pink-50 p-8 rounded-2xl hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-purple-100">
              <div className="bg-gradient-to-r from-purple-500 to-pink-600 p-3 rounded-xl w-fit mb-6">
                <Shield className="h-8 w-8 text-white" />
              </div>
              <h4 className="text-2xl font-bold text-gray-900 mb-4">Instant Verification</h4>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Organizations can verify employee credentials instantly with secure payment 
                processing and automated email confirmations.
              </p>
              <div className="flex items-center space-x-2 text-purple-600 font-medium">
                <CheckCircle className="h-4 w-4" />
                <span>Instant processing</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 px-6 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-4">
              Simple 3-Step Process
            </h3>
            <p className="text-xl text-gray-600">
              Get your academic credentials verified in minutes, not days
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                1
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-4">Create Account</h4>
              <p className="text-gray-600">
                Sign up with your academic credentials and verify your identity securely
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                2
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-4">Submit Request</h4>
              <p className="text-gray-600">
                Choose your service, provide necessary details, and complete secure payment
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-gradient-to-r from-purple-500 to-pink-600 text-white w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                3
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-4">Get Results</h4>
              <p className="text-gray-600">
                Receive your verified documents or confirmation via email within 24-48 hours
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Admin Preview Section */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-4">
              Powerful Admin Dashboard
            </h3>
            <p className="text-xl text-gray-600">
              Complete management suite for educational institutions
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: TrendingUp, title: 'Financial Analytics', desc: 'Comprehensive revenue tracking and financial reporting' },
              { icon: FileText, title: 'Request Management', desc: 'Monitor and process all transcript and verification requests' },
              { icon: Users, title: 'User Administration', desc: 'Manage student accounts and institutional access' },
              { icon: Clock, title: 'Real-time Monitoring', desc: 'Live dashboard with instant status updates' },
              { icon: Shield, title: 'Security Controls', desc: 'Advanced role-based access and audit logging' },
              { icon: CheckCircle, title: 'Quality Assurance', desc: 'Automated verification and quality checks' }
            ].map((feature, index) => (
              <div key={index} className="bg-gradient-to-br from-gray-50 to-blue-50 p-6 rounded-xl border border-gray-200 hover:shadow-lg transition-all duration-300">
                <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
                <h4 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h4>
                <p className="text-gray-600 text-sm">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-gray-900 to-blue-900 text-white py-12">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-gradient-to-r from-blue-400 to-purple-400 p-2 rounded-lg">
                  <GraduationCap className="h-6 w-6 text-white" />
                </div>
                <span className="text-xl font-bold">EduTranscript</span>
              </div>
              <p className="text-gray-300 text-sm">
                Empowering academic excellence through secure, reliable credential management.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-white transition-colors">Transcript Requests</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Result Verification</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Document Authentication</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">System Status</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Security</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 pt-8 text-center text-sm text-gray-300">
            <p>&copy; {new Date().getFullYear()} EduTranscript Portal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}